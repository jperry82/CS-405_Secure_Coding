// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>

// Custom exception class derived from std::exception
class CustomException : public std::exception {
public:
    const char* what() const noexcept override {
        return "Custom Exception: Custom logic error.";
    }
};

bool do_even_more_custom_application_logic()
{
    // Throw a standard exception
    std::cout << "Running Even More Custom Application Logic." << std::endl;
    throw std::runtime_error("Error in Even More Custom Application Logic.");
    return true;
}
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    try {
        // Wrap the call to do_even_more_custom_application_logic with an exception handler
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e) {
        // Handle standard exception and display the message
        std::cout << "Exception caught: " << e.what() << std::endl;
    }

    // Throw a custom exception
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den) {
    if (den == 0) {
        // Throw a standard exception for division by zero
        throw std::invalid_argument("Division by zero is not allowed");
    }
    return num / den;
}

void do_division() noexcept {
    float numerator = 10.0f;
    float denominator = 0;

    try {
        // Attempt division
        float result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& e) {
        // Catch and display only exceptions thrown by divide
        std::cout << "Exception caught in division: " << e.what() << std::endl;
    }
}

int main() {
    try {
        std::cout << "Exceptions Tests!" << std::endl;

        // Call division function
        do_division();

        // Call custom application logic
        do_custom_application_logic();

    }
    catch (const CustomException& e) {
        // Catch custom exceptions
        std::cout << "Custom Exception caught in main: " << e.what() << std::endl;
    }
    catch (const std::exception& e) {
        // Catch standard exceptions
        std::cout << "Standard Exception caught in main: " << e.what() << std::endl;
    }
    catch (...) {
        // Catch all other exceptions
        std::cout << "An unknown error occurred in main." << std::endl;
    }

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
#include <iostream>
#include <sqlite3.h>
#include <string>

// Function to execute SQL commands
// This function is used for executing general SQL queries such as table creation.
void executeSQL(sqlite3* db, const std::string& sql) {
    char* errMsg = nullptr;
    int rc = sqlite3_exec(db, sql.c_str(), nullptr, nullptr, &errMsg);
    if (rc != SQLITE_OK) {
        std::cerr << "SQL error: " << errMsg << std::endl;
        sqlite3_free(errMsg);
    }
}

// Function to store encrypted data in the database
// Modification: Added parameterized SQL statements to prevent SQL injection
void storeEncryptedData(sqlite3* db, const std::string& data) {
    std::string sql = "INSERT INTO encrypted_data (data) VALUES (?);";
    sqlite3_stmt* stmt;

    if (sqlite3_prepare_v2(db, sql.c_str(), -1, &stmt, nullptr) == SQLITE_OK) {
        sqlite3_bind_text(stmt, 1, data.c_str(), -1, SQLITE_STATIC);
        sqlite3_step(stmt);
        sqlite3_finalize(stmt);
    }
    else {
        std::cerr << "Failed to prepare statement." << std::endl;
    }
}

// Function to retrieve encrypted data from the database
// Modification: Using prepared statements for secure data retrieval
void retrieveEncryptedData(sqlite3* db) {
    std::string sql = "SELECT data FROM encrypted_data;";
    sqlite3_stmt* stmt;

    if (sqlite3_prepare_v2(db, sql.c_str(), -1, &stmt, nullptr) == SQLITE_OK) {
        while (sqlite3_step(stmt) == SQLITE_ROW) {
            std::cout << "Encrypted Data: " << sqlite3_column_text(stmt, 0) << std::endl;
        }
    }
    else {
        std::cerr << "Failed to execute query." << std::endl;
    }
    sqlite3_finalize(stmt);
}

int main() {
    sqlite3* db;
    int rc = sqlite3_open("encryption.db", &db);
    if (rc) {
        std::cerr << "Can't open database: " << sqlite3_errmsg(db) << std::endl;
        return rc;
    }

    // Creating the encrypted data table with an ID for better indexing
    // Modification: Ensured table creation follows best practices for database integrity
    std::string createTableSQL = "CREATE TABLE IF NOT EXISTS encrypted_data (id INTEGER PRIMARY KEY AUTOINCREMENT, data TEXT NOT NULL);";
    executeSQL(db, createTableSQL);

    // Example usage of storing and retrieving encrypted data
    storeEncryptedData(db, "ExampleEncryptedString");
    retrieveEncryptedData(db);

    sqlite3_close(db);
    return 0;
}
